function Hp = essential_flat(H)
    %Reshape a [3x6xk] matrix to a [3x3x2k] matrix
    Hp = reshape(H,3,3,[]);
end
